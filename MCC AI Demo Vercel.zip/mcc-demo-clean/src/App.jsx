import { useState, useRef, useEffect } from "react";

const SYSTEM_PROMPT = `You are an AI patient concierge for Melbourne Cosmetic Centre (MCC Studio), a boutique cosmetic clinic in Docklands, Melbourne. You were created by AVAR Digital.

Your role is to warmly greet patients, answer questions about cosmetic treatments, qualify them appropriately, and guide them toward booking a consultation — all in MCC's tone: warm, professional, knowledgeable, and safety-first. Never pushy.

## MCC PHILOSOPHY
- Anatomy-first, safety always
- Consultation before any treatment — no exceptions
- Natural, subtle outcomes — never overdone
- You connect patients with the right practitioner — you do not perform procedures

## TREATMENTS YOU CAN DISCUSS

1. Lip Filler — Hyaluronic acid filler to add volume, shape, and definition to the lips. Results last 6–12 months. Topical numbing cream applied beforehand. Minimal downtime. Consultation required first.

2. Anti-Wrinkle Injections — Neuromodulator treatment to relax movement-driven facial lines such as forehead lines, frown lines between the brows, and crow's feet. Cannot name specific products due to Australian regulations. Results typically last 3–4 months.

3. Dermal Fillers — Used to restore lost volume and contour areas including cheeks, jawline, chin, and smile lines (nasolabial folds). Results vary by area, generally 9–18 months.

4. Non-Surgical Rhinoplasty (Liquid Nose Job) — Dermal filler injected to reshape the nose tip, smooth bumps, or lift the bridge. Suitable for minor cosmetic concerns only. NOT suitable for patients who have had previous nasal surgery or significant nasal trauma.

5. Cheek & Jawline Contouring — Filler placed strategically to define structure and restore youthful volume. Results last 12–18 months.

6. Skin Boosters — Injectable hydration treatments that improve overall skin quality, texture, and radiance from within.

7. Lip Flip — A small amount of anti-wrinkle product placed above the upper lip to subtly lift the lip border. A more subtle option than filler. Lasts approximately 6–8 weeks.

## AHPRA COMPLIANCE — STRICTLY FOLLOW THESE
- NEVER name specific injectable product brands for anti-wrinkle treatments
- NEVER guarantee specific results or outcomes
- NEVER use superlatives like "best results" or "perfect"
- ALWAYS recommend a consultation before any treatment discussion
- Frame all treatments as requiring a medical assessment by a qualified practitioner
- Do not provide pricing — direct to consultation

## PATIENT QUALIFICATION
Before offering to book, naturally collect through conversation:
1. What treatment they are interested in
2. Whether they have had cosmetic treatments before (first timer vs experienced)
3. Basic medical suitability — ask gently: are they currently pregnant or breastfeeding? For rhinoplasty specifically: any previous nasal surgery?
4. What result or outcome they are hoping for — keep it conversational
5. Confirm they understand consultation comes first — no treatment on the day

RED FLAGS — if any of these come up, politely explain treatment is not suitable right now and recommend they speak with their GP:
- Currently pregnant or breastfeeding
- Active skin infection in the treatment area
- Very recent facial surgery (within 3 months)

## BOOKING
Once a patient is qualified, offer to get them booked in:
"I'd love to get you booked in for a consultation with one of our practitioners. There's no obligation — it's just a chance to chat through your goals and get expert advice tailored to you."
Then collect: full name, preferred day and time, and best contact number or email.
Confirm back: "Perfect — I'll pass your details to the team and someone will be in touch to confirm your appointment shortly."

## TONE GUIDELINES
- Warm, calm, and reassuring — like a trusted friend who works at the clinic
- Short responses — this is a chat, not an essay. Max 3–4 short paragraphs per reply.
- Use "we" and "our team" when referring to MCC
- Do not start replies with "Absolutely!" "Great question!" or similar filler phrases
- If a medical question is beyond your scope, say: "That's a great one to raise in your consultation — our practitioners will be able to give you a proper answer."
- End most replies with a gentle question to keep the conversation moving forward

## WHAT YOU DO NOT DO
- Do not discuss pricing — "Pricing is best discussed during your consultation as it depends on your individual goals"
- Do not discuss training courses or model booking programmes — "For that, I'd suggest reaching out to our team directly"
- Do not diagnose or give medical advice
- Do not discuss competitors
- Do not make the patient feel judged for their cosmetic goals`;

const SUGGESTIONS = [
  "I'm interested in lip filler",
  "What are anti-wrinkle injections?",
  "Tell me about a liquid rhinoplasty",
  "How do I book a consultation?",
  "I'm new to cosmetic treatments",
];

export default function App() {
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content: "Hi there, welcome to Melbourne Cosmetic Centre. 😊\n\nI'm here to help you explore your options and answer any questions about our treatments. Everything we do starts with a consultation — so there's no pressure at all.\n\nWhat brings you in today?"
    }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [started, setStarted] = useState(false);
  const [apiKey, setApiKey] = useState("");
  const [keySet, setKeySet] = useState(false);
  const bottomRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const send = async (text) => {
    const userText = text || input.trim();
    if (!userText || loading) return;
    setInput("");
    setStarted(true);

    const newMessages = [...messages, { role: "user", content: userText }];
    setMessages(newMessages);
    setLoading(true);

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": apiKey,
          "anthropic-version": "2023-06-01",
          "anthropic-dangerous-allow-browser": "true"
        },
        body: JSON.stringify({
          model: "claude-haiku-4-5-20251001",
          max_tokens: 1000,
          system: SYSTEM_PROMPT,
          messages: newMessages.map(m => ({ role: m.role, content: m.content }))
        })
      });
      const data = await res.json();
      const reply = data.content?.[0]?.text || "Sorry, something went wrong. Please try again.";
      setMessages(prev => [...prev, { role: "assistant", content: reply }]);
    } catch {
      setMessages(prev => [...prev, { role: "assistant", content: "Something went wrong. Please check your connection and try again." }]);
    }
    setLoading(false);
    setTimeout(() => inputRef.current?.focus(), 100);
  };

  const handleKey = (e) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); }
  };

  // API Key gate screen
  if (!keySet) {
    return (
      <div style={{
        minHeight: "100vh", background: "#0e0e0e",
        display: "flex", flexDirection: "column",
        alignItems: "center", justifyContent: "center",
        padding: 24, fontFamily: "'DM Sans', sans-serif"
      }}>
        <div style={{
          width: "100%", maxWidth: 420,
          background: "#141414", border: "1px solid #1e1e1e",
          borderRadius: 16, padding: "36px 32px"
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 28 }}>
            <div style={{
              width: 44, height: 44, borderRadius: "50%",
              background: "linear-gradient(135deg, #9DDAA3, #5BAF65)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 18, fontWeight: 700, color: "#111",
              fontFamily: "'Cormorant Garamond', serif"
            }}>M</div>
            <div>
              <div style={{ fontSize: 15, fontWeight: 500, color: "#fff" }}>MCC Studio</div>
              <div style={{ fontSize: 11, color: "#9DDAA3" }}>AI Patient Concierge Demo</div>
            </div>
          </div>
          <div style={{ fontSize: 13, color: "#888", lineHeight: 1.7, marginBottom: 24 }}>
            This demo requires an Anthropic API key to run the AI. Enter yours below to get started.
            <br /><br />
            <span style={{ color: "#555", fontSize: 12 }}>Your key is used only in this session and never stored.</span>
          </div>
          <input
            type="password"
            placeholder="sk-ant-..."
            value={apiKey}
            onChange={e => setApiKey(e.target.value)}
            onKeyDown={e => e.key === "Enter" && apiKey.startsWith("sk-ant-") && setKeySet(true)}
            style={{
              width: "100%", background: "#1e1e1e", border: "1px solid #2a2a2a",
              borderRadius: 10, padding: "11px 14px", color: "#e8e8e5",
              fontSize: 14, fontFamily: "'DM Sans', sans-serif", marginBottom: 12,
              outline: "none"
            }}
          />
          <button
            onClick={() => setKeySet(true)}
            disabled={!apiKey.startsWith("sk-ant-")}
            style={{
              width: "100%", padding: "12px",
              background: apiKey.startsWith("sk-ant-") ? "#9DDAA3" : "#1e1e1e",
              border: "none", borderRadius: 10,
              color: apiKey.startsWith("sk-ant-") ? "#111" : "#444",
              fontSize: 14, fontWeight: 500, cursor: apiKey.startsWith("sk-ant-") ? "pointer" : "not-allowed",
              fontFamily: "'DM Sans', sans-serif", transition: "all 0.15s"
            }}
          >
            Launch Demo
          </button>
        </div>
        <div style={{ marginTop: 16, fontSize: 11, color: "#333", textAlign: "center" }}>
          Powered by AVAR Digital · Built for MCC Studio
        </div>
      </div>
    );
  }

  return (
    <div style={{
      minHeight: "100vh", background: "#0e0e0e",
      display: "flex", flexDirection: "column",
      alignItems: "center", justifyContent: "center",
      fontFamily: "'DM Sans', sans-serif", padding: "20px 16px"
    }}>
      <style>{`
        * { box-sizing: border-box; }
        @keyframes bounce { 0%,80%,100%{transform:translateY(0)} 40%{transform:translateY(-6px)} }
        @keyframes fadeUp { from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:translateY(0)} }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
        ::-webkit-scrollbar{width:4px} ::-webkit-scrollbar-track{background:transparent} ::-webkit-scrollbar-thumb{background:#2a2a2a;border-radius:2px}
        textarea{resize:none} textarea:focus{outline:none}
        input:focus{outline:none}
      `}</style>

      {/* Header */}
      <div style={{
        width: "100%", maxWidth: 680,
        display: "flex", alignItems: "center", justifyContent: "space-between",
        marginBottom: 16, padding: "0 4px"
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{
            width: 40, height: 40, borderRadius: "50%",
            background: "linear-gradient(135deg, #9DDAA3, #5BAF65)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 16, fontWeight: 700, color: "#111",
            fontFamily: "'Cormorant Garamond', serif"
          }}>M</div>
          <div>
            <div style={{ fontSize: 14, fontWeight: 500, color: "#fff" }}>MCC Studio</div>
            <div style={{ fontSize: 11, color: "#9DDAA3", display: "flex", alignItems: "center", gap: 5 }}>
              <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#9DDAA3", display: "inline-block", animation: "pulse 2s infinite" }} />
              AI Patient Concierge · Online now
            </div>
          </div>
        </div>
        <div style={{ fontSize: 10, color: "#333", letterSpacing: "0.15em", textTransform: "uppercase" }}>
          Powered by AVAR Digital
        </div>
      </div>

      {/* Chat window */}
      <div style={{
        width: "100%", maxWidth: 680,
        background: "#141414", border: "1px solid #1e1e1e",
        borderRadius: 16, display: "flex", flexDirection: "column",
        height: "calc(100vh - 160px)", maxHeight: 660,
        overflow: "hidden", boxShadow: "0 32px 80px rgba(0,0,0,0.6)"
      }}>

        {/* Messages */}
        <div style={{ flex: 1, overflowY: "auto", padding: "24px 24px 12px", display: "flex", flexDirection: "column", gap: 14 }}>
          {messages.map((msg, i) => (
            <div key={i} style={{
              display: "flex", flexDirection: msg.role === "user" ? "row-reverse" : "row",
              alignItems: "flex-end", gap: 10,
              animation: "fadeUp 0.25s ease forwards"
            }}>
              {msg.role === "assistant" && (
                <div style={{
                  width: 28, height: 28, borderRadius: "50%", flexShrink: 0,
                  background: "linear-gradient(135deg, #9DDAA3, #5BAF65)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 11, fontWeight: 700, color: "#111",
                  fontFamily: "'Cormorant Garamond', serif"
                }}>M</div>
              )}
              <div style={{
                maxWidth: "78%",
                background: msg.role === "user" ? "#9DDAA3" : "#1e1e1e",
                color: msg.role === "user" ? "#111" : "#e8e8e5",
                padding: "11px 15px",
                borderRadius: msg.role === "user" ? "18px 18px 4px 18px" : "18px 18px 18px 4px",
                fontSize: 14, lineHeight: 1.72, fontWeight: msg.role === "user" ? 500 : 400,
                whiteSpace: "pre-wrap", wordBreak: "break-word"
              }}>
                {msg.content}
              </div>
            </div>
          ))}

          {loading && (
            <div style={{ display: "flex", alignItems: "flex-end", gap: 10, animation: "fadeUp 0.25s ease forwards" }}>
              <div style={{
                width: 28, height: 28, borderRadius: "50%", flexShrink: 0,
                background: "linear-gradient(135deg, #9DDAA3, #5BAF65)",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 11, fontWeight: 700, color: "#111", fontFamily: "'Cormorant Garamond', serif"
              }}>M</div>
              <div style={{ background: "#1e1e1e", padding: "12px 16px", borderRadius: "18px 18px 18px 4px" }}>
                <div style={{ display: "flex", gap: 5, alignItems: "center" }}>
                  {[0,1,2].map(i => (
                    <div key={i} style={{
                      width: 7, height: 7, borderRadius: "50%", background: "#9DDAA3",
                      animation: "bounce 1.2s infinite", animationDelay: `${i*0.2}s`
                    }} />
                  ))}
                </div>
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Suggestions */}
        {!started && (
          <div style={{ padding: "0 24px 10px", display: "flex", gap: 8, flexWrap: "wrap" }}>
            {SUGGESTIONS.map((s, i) => (
              <button key={i} onClick={() => send(s)} style={{
                background: "transparent", border: "1px solid #2a2a2a",
                color: "#777", borderRadius: 20, padding: "6px 13px",
                fontSize: 12, fontFamily: "'DM Sans', sans-serif",
                cursor: "pointer", transition: "all 0.15s", whiteSpace: "nowrap"
              }}
                onMouseEnter={e => { e.target.style.borderColor="#9DDAA3"; e.target.style.color="#9DDAA3"; }}
                onMouseLeave={e => { e.target.style.borderColor="#2a2a2a"; e.target.style.color="#777"; }}
              >{s}</button>
            ))}
          </div>
        )}

        {/* Input */}
        <div style={{ padding: "10px 14px 14px", borderTop: "1px solid #1e1e1e", display: "flex", gap: 10, alignItems: "flex-end" }}>
          <textarea
            ref={inputRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKey}
            placeholder="Ask about treatments, book a consultation..."
            rows={1}
            style={{
              flex: 1, background: "#1e1e1e", border: "1px solid #2a2a2a",
              borderRadius: 12, padding: "10px 14px",
              color: "#e8e8e5", fontSize: 14, fontFamily: "'DM Sans', sans-serif",
              lineHeight: 1.5, maxHeight: 120, overflowY: "auto", transition: "border-color 0.15s"
            }}
            onFocus={e => e.target.style.borderColor="#9DDAA3"}
            onBlur={e => e.target.style.borderColor="#2a2a2a"}
          />
          <button
            onClick={() => send()}
            disabled={!input.trim() || loading}
            style={{
              width: 40, height: 40, borderRadius: "50%", border: "none", flexShrink: 0,
              background: input.trim() && !loading ? "#9DDAA3" : "#1e1e1e",
              cursor: input.trim() && !loading ? "pointer" : "not-allowed",
              display: "flex", alignItems: "center", justifyContent: "center",
              transition: "all 0.15s"
            }}
          >
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
              <path d="M22 2L11 13" stroke={input.trim()&&!loading?"#111":"#444"} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M22 2L15 22L11 13L2 9L22 2Z" stroke={input.trim()&&!loading?"#111":"#444"} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
        </div>
      </div>

      <div style={{ marginTop: 12, fontSize: 11, color: "#2a2a2a", textAlign: "center" }}>
        Demo by AVAR Digital · All treatments require a clinical consultation with a qualified practitioner
      </div>
    </div>
  );
}
